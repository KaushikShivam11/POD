sap.ui.define([
	"com/enoc/ZProof_delivery/test/unit/controller/View1.controller"
], function () {
	"use strict";
});