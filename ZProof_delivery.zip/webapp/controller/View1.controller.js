sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/odata/ODataModel",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/IconPool"
], function (Controller, MessageToast, JSONModel, Filter, ODataModel, FilterOperator, IconPool) {
	"use strict";

	return Controller.extend("com.enoc.ZProof_delivery.controller.View1", {
		onInit: function () {

			IconPool.registerFont({
				fontFamily: "BusinessSuiteInAppSymbols",
				fontURI: jQuery.sap.getModulePath("sap.ushell.themes.base.fonts")
			});

			var oFilter = this.getView().byId("filterData");
			oFilter.addEventDelegate({
				"onAfterRendering": function (oEvent) {
					var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
					var oButton = oEvent.srcControl._oSearchButton;
					oButton.setText(oResourceBundle.getText("search_button"));
					oButton.setType("Accept");
				}.bind(this)
			});
			/*

						if (navigator.geolocation) {
							navigator.geolocation.getCurrentPosition(function (position) {
								this.byId("infoLati").setText(position.coords.latitude);
								this.byId("infoLongi").setText(position.coords.longitude);
							}.bind(this))
						} else {
							MessageToast.show("Geolocation is not supported by this browser.");
						}*/
			var oView = this.getView();
			sap.ui.getCore().getMessageManager().registerObject(oView, true);
		},

		onQtyChange: function (oEvent) {
			var oSource = oEvent.getSource();
			if (/^\d+$/.test(oSource.getValue()) === false && oSource.getId() !== "__xmlview0--truckNum") {
				oSource.setValueState("Error");
				oSource.setValueStateText("Enter the Valid Input Value");
			} else if (/^[a-z0-9]+$/i.test(oSource.getValue()) === false && oSource.getId() === "__xmlview0--truckNum") {
				oSource.setValueState("Error");
				oSource.setValueStateText("Enter the Valid Input Value");
			} else {
				this.byId("freightNum").setValueState("None");
				this.byId("deliveryNum").setValueState("None");
				this.byId("truckNum").setValueState("None");
			}
		},

		onSearch: function () {
			var freightNum = this.byId("freightNum").getValue();
			var deliveryNum = this.byId("deliveryNum").getValue();
			var truckNum = this.byId("truckNum").getValue();
			if ((/^\d+$/.test(freightNum) === false && freightNum !== "") || (/^\d+$/.test(deliveryNum) === false && deliveryNum !== "") || (
					/^[a-z0-9]+$/i.test(truckNum) === false && truckNum !== "")) {
				this.byId("freightNum").setValueState("Error");
				this.byId("deliveryNum").setValueState("Error");
				this.byId("truckNum").setValueState("Error");
				var msg = "Enter the Valid Input Value!!";
				MessageToast.show(msg);
			} else {

				this.byId("freightNum").setValueState("None");
				this.byId("deliveryNum").setValueState("None");
				this.byId("truckNum").setValueState("None");

				var odatamodel = this.getView().getModel();
				var jsonmodel = new JSONModel();
				var freightFilter = new Filter("FrtOrdNum", FilterOperator.EQ, freightNum);
				var deliveryFilter = new Filter("DelOrdNum", FilterOperator.EQ, deliveryNum);
				var truckFilter = new Filter("TruckNum", FilterOperator.EQ, truckNum);
				var oTable = this.byId("infoTable");
				oTable.setBusy(true);
				odatamodel.read("/FreightDetailsSet", {
					filters: [freightFilter, deliveryFilter, truckFilter],
					success: function (odata, response) {

						jsonmodel.setData(odata.results);

						if (jsonmodel.getData().length !== 0) {
							if (jsonmodel.getData()[0].TMFlag.trim() === "" & jsonmodel.getData()[0].DeliveryNum.trim() !== 0) {
								for (var i = 0; i < jsonmodel.getData().length; i++) {
									if (jsonmodel.getData()[i].FrtUnit === "")
										jsonmodel.getData()[i].FrtUnit = "0";
									if (jsonmodel.getData()[i].FrtOrdNum === "")
										jsonmodel.getData()[i].FrtOrdNum = "0";
								}
								oTable.getColumns()[0].setVisible(false);
								oTable.getColumns()[1].setVisible(true);
							} else {
								oTable.getColumns()[1].setVisible(false);
								oTable.getColumns()[0].setVisible(true);
							}
						} else {
							oTable.setNoDataText("Invalid Inputs!!");
						}

						oTable.setModel(jsonmodel, "info");

						oTable.setBusy(false);
					}.bind(this),
					error: function (erMsg) {
						MessageToast.show("Failed:A001:" + erMsg);
						oTable.setBusy(false);
					}
				});

				this.byId("tabBar").setVisible(true);

			}
			/*if (freightNum === "" & deliveryNum === "" & truckNum === "") {
				this.byId("freightNum").setValueState("Error");
				this.byId("deliveryNum").setValueState("Error");
				this.byId("truckNum").setValueState("Error");
				var msg = "Please input any of above fields!!";
				MessageToast.show(msg);
			} else {}*/
		},

		iconTabBarSelect: function (oEvent) {
			this.keyGlobal = oEvent.getParameter("key");
			var oBinding = this.byId("infoTable").getBinding("items");
			var aFilters = [];
			var oDataFilter;

			if (this.keyGlobal === "Yes") {
				oDataFilter = new Filter("rej", "EQ", this.keyGlobal);
				aFilters.push([oDataFilter]);
			} else if (this.keyGlobal === "No") {
				oDataFilter = new Filter("rej", "EQ", this.keyGlobal);
				aFilters.push([oDataFilter]);
			}

			oBinding.filter(aFilters);

		},

		getDetails: function (oEvent) {

			var oSource = oEvent.getSource();
			var oRow = oSource.getParent();
			var oTable = oRow.getParent();
			var oIndex = oTable.indexOfItem(oRow);
			var table = this.byId("infoTable");
			var oTableData = table.getItems();

			var data = {
				"freightNumber": oTableData[oIndex].getAggregation("cells")[0].getText(),
				"DeliveryNum": oTableData[oIndex].getAggregation("cells")[4].getText(),
				"frtOrdNum": (oTableData[oIndex].getAggregation("cells")[5].getText() === "") ? " " : oTableData[oIndex].getAggregation("cells")[
					5].getText(),
				"locationInfo": oTableData[oIndex].getAggregation("cells")[6].getText(),
				"trucknum": (this.byId("infoTable").getModel("info").getData()[0].TruckNum === "") ? " " : this.byId("infoTable").getModel("info")
					.getData()[0].TruckNum,
				"TMFlag": (this.byId("infoTable").getModel("info").getData()[0].TMFlag === "") ? " " : this.byId("infoTable").getModel("info").getData()[
					0].TMFlag,
				"FUFlag": (oIndex === (oTableData.length - 1)) ? "X" : " "
			};

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.navTo("RouteView2", data);

		}
	});
});