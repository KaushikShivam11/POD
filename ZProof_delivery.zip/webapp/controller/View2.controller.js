sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"com/enoc/ZProof_delivery/controller/SignaturePad",
	"sap/ui/model/odata/ODataModel",
	"sap/ui/model/FilterOperator",
	"sap/m/UploadCollectionParameter"
], function (Controller, History, JSONModel, MessageBox, MessageToast, Filter, SignaturePad, ODataModel, FilterOperator,
	UploadCollectionParameter) {
	"use strict";

	return Controller.extend("com.enoc.ZProof_delivery.controller.View2", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.enoc.view.View2
		 */
		onInit: function () {

			var oUpload = this.getView().byId("UploadCollection");
			oUpload.addEventDelegate({
				"onAfterRendering": function (oEvent) {
					var oUploader = oEvent.srcControl._oFileUploader;
					oUploader.setIcon("sap-icon://camera");
					oUploader.setButtonText(" ");
				}
			});
			var oEventModel = new JSONModel();
			this.getView().setModel(oEventModel, "eventModel");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RouteView2").attachMatched(this.onRouteMatched, this);

		},

		onRouteMatched: function (oEvent) {
			this.byId("proofLayout").setVisible(true);
			this.byId("Events").setVisible(true);
			this.byId("infoText").setText("");
			this.byId("UploadCollection").removeAllItems();
			this.byId("btnSave").setEnabled(true);
			this.byId("arrivalDest").setEnabled(true);
			this.byId("unload").setEnabled(false);
			this.byId("proofCheckBox").setEnabled(false);
			this.byId("unPlannedEvents").setVisible(true);

			this.byId("signBox").setSelected(false);
			this.singInfo();

			this.byId("proofCheckBox").setSelected(false);
			this.proofOfDelivery();

			this.byId("arrivalDest").setSelected(false);
			this.byId("unload").setSelected(false);
			this.byId("multiEvents").removeAllTokens();
			var oArguments = oEvent.getParameter("arguments");
			this.jsonM = new JSONModel();
			this.jsonM.setData(
				oArguments
			);

			var delQty = true;

			this.getView().setModel(this.jsonM, "info");

			var odatamodel = this.getView().getModel();
			var jsonmodel = new JSONModel();

			var otable = this.byId("detailTable");
			otable.setBusy(true);

			if (parseFloat(oArguments.freightNumber) === 0) {
				oArguments.freightNumber = "";
				this.byId("frLabel").setVisible(false);
				this.byId("frText").setVisible(false);
			} else {
				this.byId("frLabel").setVisible(true);
				this.byId("frText").setVisible(true);
			}

			if (parseFloat(oArguments.frtOrdNum) === 0) {
				oArguments.frtOrdNum = "";
			}

			var freightFilter = new Filter("FrtUnit", FilterOperator.EQ, oArguments.freightNumber);
			var freightOrdFilter = new Filter("FrtOrdr", FilterOperator.EQ, oArguments.frtOrdNum);
			var locationFilter = new Filter("Location", FilterOperator.EQ, oArguments.locationInfo);
			var delOrdNumFilter = new Filter("Delivery", FilterOperator.EQ, oArguments.DeliveryNum);
			odatamodel.read("/ProductDetailsSet", {
				filters: [freightFilter, freightOrdFilter, locationFilter, delOrdNumFilter],
				success: function (odata, response) {
					jsonmodel.setData(odata.results);
					this.getView().byId("detailTable").setModel(jsonmodel, "detail");
					this.getView().setModel(jsonmodel, "detail");
					if (odata.results.length !== 0) {
						this.SalesOrder = jsonmodel.getData()[0].SalesOrder;

						if (jsonmodel.getData()[0].PODFlag.trim() === "") {
							this.byId("arrivalDest").setEnabled(false);
							this.byId("proofCheckBox").setEnabled(false);
							this.byId("unload").setEnabled(false);
							this.byId("btnSave").setEnabled(false);
							delQty = false;
							this.byId("infoText").setText("POD is not relevant!!");
						}

						if (jsonmodel.getData()[0].Status.toUpperCase() === "C") {
							this.byId("arrivalDest").setEnabled(false);
							this.byId("proofCheckBox").setEnabled(false);
							this.byId("unload").setEnabled(false);
							this.byId("btnSave").setEnabled(false);
							delQty = false;
							this.byId("infoText").setText("POD already done!!");
						}

						if (jsonmodel.getData()[0].Status.trim() === "") {
							this.byId("arrivalDest").setEnabled(false);
							this.byId("proofCheckBox").setEnabled(false);
							this.byId("unload").setEnabled(false);
							this.byId("btnSave").setEnabled(false);
							delQty = false;
							this.byId("infoText").setText("Delivery Not Valid for POD!!");
						}

						if (jsonmodel.getData()[0].Arrival.toUpperCase() === "X") {
							this.byId("arrivalDest").setSelected(true);
							this.byId("arrivalDest").setEnabled(false);
							this.byId("unload").setSelected(false);
							this.byId("unload").setEnabled(true);
						}
						if (jsonmodel.getData()[0].Unload.toUpperCase() === "X") {
							this.byId("unload").setSelected(true);
							this.byId("unload").setEnabled(false);
						}
						if (jsonmodel.getData()[0].POD.toUpperCase() === "X") {
							this.byId("proofCheckBox").setSelected(true);
							this.byId("proofCheckBox").setEnabled(false);
							this.byId("btnSave").setEnabled(false);
						}

						if ((jsonmodel.getData()[0].Status.toUpperCase() === "A" & jsonmodel.getData()[0].PODFlag.toUpperCase() === "X" & jsonmodel.getData()[
								0].Unload.toUpperCase() === "X") || (
								jsonmodel
								.getData()[0].Status.toUpperCase() === "B" & jsonmodel.getData()[0].PODFlag.toUpperCase() === "X" & jsonmodel.getData()[0].Unload
								.toUpperCase() === "X")) {
							this.byId("proofCheckBox").setSelected(false);
							this.byId("proofCheckBox").setEnabled(true);
							this.byId("btnSave").setEnabled(true);
						}

						if (oArguments.freightNumber === "") {
							this.byId("arrivalDest").setEnabled(false);
							this.byId("unload").setEnabled(false);
						}

						var oTableData = otable.getItems();

						for (var i = 0; i < oTableData.length; i++) {
							oTableData[i].getAggregation("cells")[6].setEnabled(false);
							oTableData[i].getAggregation("cells")[6].setSelectedItem(null);
							oTableData[i].getAggregation("cells")[6].setValueState("None");
							oTableData[i].getAggregation("cells")[4].setEnabled(delQty);
							oTableData[i].getAggregation("cells")[4].setEnabled(/^\d+$/.test(parseFloat(oTableData[i].getAggregation("cells")[3].getText()
								.split(
									" ")[0])));
							oTableData[i].getAggregation("cells")[5].setText(parseFloat(oTableData[i].getAggregation("cells")[3].getText().split(
								" ")[0]) - parseFloat(oTableData[i].getAggregation("cells")[4].getValue() === "" ? "0" : oTableData[i].getAggregation(
								"cells")[4].getValue()));
							oTableData[i].getAggregation("cells")[5].setText(/^\d+$/.test(parseFloat(oTableData[i].getAggregation("cells")[3].getText().split(
								" ")[0])) === false ? "" : parseFloat(oTableData[i].getAggregation("cells")[3].getText().split(
								" ")[0]) - parseFloat(oTableData[i].getAggregation("cells")[4].getValue() === "" ? "0" : oTableData[i].getAggregation(
								"cells")[4].getValue()));
							oTableData[i].getAggregation("cells")[6].setSelectedKey(jsonmodel.getData()[i].Reason);
						}
					}

					if (this.getView().getModel("info").getData().TMFlag !== "X" && jsonmodel.getData()[0].Status.toUpperCase() !== "C") {
						this.byId("proofLayout").setVisible(false);
						this.byId("unPlannedEvents").setVisible(false);
						this.byId("Events").setVisible(true);
						this.byId("UploadCollection").removeAllItems();
						this.byId("btnSave").setEnabled(true);
						this.byId("arrivalDest").setEnabled(false);
						this.byId("unload").setEnabled(false);
						this.byId("proofCheckBox").setEnabled(true);
						this.byId("signBox").setSelected(false);
						this.byId("proofCheckBox").setSelected(false);
						this.byId("arrivalDest").setSelected(false);
						this.byId("unload").setSelected(false);
						this.byId("multiEvents").removeAllTokens();
					}

					otable.setBusy(false);
				}.bind(this),
				error: function (erMsg) {
					MessageToast.show("Failed:A002:" + erMsg);
					otable.setBusy(false);
				}
			});

			var reasonModel = new JSONModel();
			otable.setBusy(true);

			odatamodel.read("/ReasonHelpSet", {
				success: function (odata, response) {
					reasonModel.setData(odata.results);
					this.getView().byId("detailTable").setModel(reasonModel, "reason");
					otable.setBusy(false);
				}.bind(this),
				error: function (erMsg) {
					MessageToast.show("Failed:A003:" + erMsg);
					otable.setBusy(false);
				}
			});

		},

		onQtyChange: function (oEvent) {
			var oSource = oEvent.getSource();
			var oRow = oSource.getParent();
			var oTable = oRow.getParent();
			var oIndex = oTable.indexOfItem(oRow);
			var table = this.byId("detailTable");
			var oTableData = table.getItems();

			if (parseFloat(oSource.getValue()) > parseFloat(oTableData[oIndex].getAggregation("cells")[3].getText().split(" ")[0]) ||
				parseFloat(oSource.getValue()) < 0) {
				oSource.setValueState("Error");
				oSource.setValueStateText("Enter an Equal or Smaller Value than Actual Quantity");
				oSource.setValue("");
				oTableData[oIndex].getAggregation("cells")[5].setText(parseFloat(oTableData[oIndex].getAggregation("cells")[3].getText().split(" ")[
					0]));
				return;
			} else {
				oSource.setValueState("None");
			}

			if (oSource.getValue().length !== 0) {
				oTableData[oIndex].getAggregation("cells")[6].setEnabled(true);
				oTableData[oIndex].getAggregation("cells")[5].setText(parseFloat(oTableData[oIndex].getAggregation(
					"cells")[3].getText().split(" ")[0]) - parseFloat(oSource.getValue()));
			} else {
				oTableData[oIndex].getAggregation("cells")[6].setEnabled(false);
				oTableData[oIndex].getAggregation("cells")[6].setSelectedItem(null);
				oTableData[oIndex].getAggregation("cells")[5].setText(parseFloat(oTableData[oIndex].getAggregation("cells")[3].getText().split(" ")[
					0]));
			}

		},

		onReasonChange: function (oEvent) {
			var oSource = oEvent.getSource();
			oSource.setValueState("None");
		},

		onArrival: function (oEvent) {
			if (oEvent.getSource().getSelected()) {
				this.getView().byId("unload").setEnabled(true);
			} else {
				this.getView().byId("unload").setEnabled(false);
				this.getView().byId("unload").setSelected(false);
				this.byId("proofCheckBox").setEnabled(false);
				this.byId("proofCheckBox").setSelected(false);
				this.byId("signBox").setSelected(false);
				this.singInfo();
				this.byId("proofLayout").setVisible(false);
				this.clearButton();
				this.byId("UploadCollection").removeAllItems();
			}
		},

		onUnload: function (oEvent) {
			if (oEvent.getSource().getSelected()) {
				this.byId("proofCheckBox").setEnabled(true);
			} else {
				this.byId("proofCheckBox").setEnabled(false);
				this.byId("proofCheckBox").setSelected(false);
				this.byId("signBox").setSelected(false);
				this.singInfo();
				this.byId("proofLayout").setVisible(false);
				this.clearButton();
				this.byId("UploadCollection").removeAllItems();
			}
		},

		onBeforeUploadStarts: function (oEvent) {

			var idType = "Y";

			if (this.byId("idGrp").getSelectedButton().getText() === "Others") {
				idType = "Z";
			}

			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: this.jsonM.getData().frtOrdNum + "/" + oEvent.getParameter("fileName") + "/" + idType + "/" + this.jsonM.getData().freightNumber +
					"/" + this.jsonM.getData().DeliveryNum + "/" + this.jsonM.getData().trucknum + "/" + this.jsonM.getData().TMFlag
			});
			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: this.getView().getModel().getSecurityToken()
			});

			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

		},

		onUploadComplete: function (oEvent) {
			var aFiles = oEvent.getParameters().files;
			var m = new sap.ui.model.xml.XMLModel();
			m.setXML(aFiles[0].headers["sap-message"]);
			MessageToast.show(m.getProperty("/message"));
			this.getView().setBusy(false);
			this.goBack();
		},

		handleLinkPress: function () {
			var oFilterFO, oFilterLoc, oFilterAll, oEventModel;
			oFilterFO = new Filter("FrtOrdNum", FilterOperator.EQ, this.jsonM.getData().frtOrdNum);
			oFilterLoc = new Filter("Location", FilterOperator.EQ, this.jsonM.getData().locationInfo);
			oFilterAll = new Filter({
				filters: [oFilterFO, oFilterLoc],
				and: true
			});
			this.getView().getModel().read("/EventHelpSet", {
				success: function (oData) {
					this.getView().getModel("eventModel").setData(oData);
				}.bind(this),
				filters: [oFilterAll]
			});
			if (!this.oEventDialog1) {
				this.oEventDialog1 = sap.ui.xmlfragment("com.enoc.ZProof_delivery.fragments.SelectedEvents", this);
				this.getView().addDependent(this.oEventDialog1);
			}
			this.oEventDialog1.open();
		},

		onClose: function () {
			this.oEventDialog1.close();
		},

		onEventsF4: function () {
			var oFilterFO, oFilterLoc, oFilterAll, oEventModel;
			oFilterFO = new Filter("FrtOrdNum", FilterOperator.EQ, this.jsonM.getData().frtOrdNum);
			oFilterLoc = new Filter("Location", FilterOperator.EQ, this.jsonM.getData().locationInfo);
			oFilterAll = new Filter({
				filters: [oFilterFO, oFilterLoc],
				and: true
			});
			this.getView().getModel().read("/EventHelpSet", {
				success: function (oData) {
					this.getView().getModel("eventModel").setData(oData);
				}.bind(this),
				filters: [oFilterAll]
			});
			if (!this.oEventDialog) {
				this.oEventDialog = sap.ui.xmlfragment("com.enoc.ZProof_delivery.fragments.Events", this);
				this.getView().addDependent(this.oEventDialog);
			}
			this.oEventDialog.open();
		},

		handleConfirm: function (oEvent) {
			var aSelectedItems = oEvent.getParameter("selectedItems"),
				aTokens = [];
			if (aSelectedItems !== undefined && aSelectedItems.length > 0) {
				aSelectedItems.forEach(function (item, index) {
					var oToken = new sap.m.Token({
						text: item.getBindingContext("eventModel").getObject().EventName,
						key: item.getBindingContext("eventModel").getObject().EventCode
					});
					aTokens.push(oToken);
				}.bind(this));
			}
			this.getView().byId("multiEvents").setTokens(aTokens);
		},

		onPressSave: function () {

			if (this.byId("arrivalDest").getSelected() && !this.byId("arrivalDest").getEnabled() && this.byId("unload").getSelected() && !this.byId(
					"unload").getEnabled() && !this.byId("proofCheckBox").getSelected()) {
				MessageBox.error("Please Select POD CheckBox");
				return;
			}

			if (this.getView().getModel("info").getData().TMFlag !== "X" && this.getView().getModel("detail").getData()[0].Status.toUpperCase() !==
				"C" && !this.byId("proofCheckBox").getSelected()) {
				MessageBox.error("Please Select POD CheckBox");
				return;
			}

			var table = this.byId("detailTable");
			var oTableData = table.getItems();

			var arrivalCheck = "";
			var unloadCheck = "";
			var proofCheck = "";

			if (this.byId("arrivalDest").getSelected() && this.byId("arrivalDest").getEnabled())
				arrivalCheck = "X";
			if (this.byId("unload").getSelected() && this.byId("unload").getEnabled())
				unloadCheck = "X";
			if (this.byId("proofCheckBox").getSelected())
				proofCheck = "X";
			if (!this.byId("arrivalDest").getSelected() && this.byId("arrivalDest").getEnabled()) {
				MessageBox.error("Please Select Arrival CheckBox");
				return;
			}
			if (!this.byId("unload").getSelected() && this.byId("unload").getEnabled() && this.byId("arrivalDest").getSelected() && !
				this.byId("arrivalDest").getEnabled()) {
				MessageBox.error("Please Select Unload CheckBox");
				return;
			}
			var arrayData = [];
			var oProductsPayload = {};
			for (var i = 0; i < oTableData.length; i++) {

				if (oTableData[i].getAggregation("cells")[6].getSelectedKey() === "" &
					oTableData[i].getAggregation("cells")[4].getValue().trim() !== "") {
					oTableData[i].getAggregation("cells")[6].setValueState("Error");
					var msg = "Please input above fields!!";
					MessageToast.show(msg);
					return;
				}

				arrayData[i] = {
					FrtUnit: this.jsonM.getData().freightNumber,
					ItemNo: oTableData[i].getAggregation("cells")[0].getText(),
					Product: oTableData[i].getAggregation("cells")[1].getText(),
					MatDesc: oTableData[i].getAggregation("cells")[2].getText(),
					Quantity: (oTableData[i].getAggregation("cells")[3].getText().split(" "))[0],
					DelQty: oTableData[i].getAggregation("cells")[4].getValue(),
					Arrival: arrivalCheck,
					Unload: unloadCheck,
					POD: proofCheck,
					Reason: oTableData[i].getAggregation("cells")[6].getSelectedKey(),
					FrtOrdr: this.jsonM.getData().frtOrdNum,
					Location: this.jsonM.getData().locationInfo,
					Delivery: this.jsonM.getData().DeliveryNum,
					SalesOrder: this.SalesOrder
				};
			}

			var aEventTokens = this.getView().byId("multiEvents").getTokens();
			if (aEventTokens != undefined && aEventTokens.length > 0) {
				aEventTokens.forEach(function (item) {
					switch (item.getText()) {
					case "Accident":
						oProductsPayload.Accident = item.getKey();
						break;
					case "Block for Execution":
						oProductsPayload.Block = item.getKey();
						break;
					case "Closed Site/Office":
						oProductsPayload.Close = item.getKey();
						break;
					case "Damage Product":
						oProductsPayload.Damage = item.getKey();
						break;
					case "Delay at Destination":
						oProductsPayload.Delay = item.getKey();
						break;
					case "Unloading Service (Forklift)":
						oProductsPayload.Forklift = item.getKey();
						break;
					case "No Parking":
						oProductsPayload.Parking = item.getKey();
						break;
					case "Order Cancelled":
						oProductsPayload.OrdCan = item.getKey();
						break;
					case "Product Spillage":
						oProductsPayload.Spillage = item.getKey();
						break;
					case "Delay due to Traffic":
						oProductsPayload.DelayTraffic = item.getKey();
						break;
					}
				}.bind(this));
			}

			var odatamodelupdate = this.getView().getModel();
			var planiImg =
				"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAABkCAYAAADDhn8LAAACoklEQVR4Xu3VsRGAQAwEMei/6KcBINj0RO7A8u9wn3PO5SNA4FXgFoiXQeBbQCBeB4EfAYF4HgQE4g0QaAL+IM3N1IiAQEYObc0mIJDmZmpEQCAjh7ZmExBIczM1IiCQkUNbswkIpLmZGhEQyMihrdkEBNLcTI0ICGTk0NZsAgJpbqZGBAQycmhrNgGBNDdTIwICGTm0NZuAQJqbqREBgYwc2ppNQCDNzdSIgEBGDm3NJiCQ5mZqREAgI4e2ZhMQSHMzNSIgkJFDW7MJCKS5mRoREMjIoa3ZBATS3EyNCAhk5NDWbAICaW6mRgQEMnJoazYBgTQ3UyMCAhk5tDWbgECam6kRAYGMHNqaTUAgzc3UiIBARg5tzSYgkOZmakRAICOHtmYTEEhzMzUiIJCRQ1uzCQikuZkaERDIyKGt2QQE0txMjQgIZOTQ1mwCAmlupkYEBDJyaGs2AYE0N1MjAgIZObQ1m4BAmpupEQGBjBzamk1AIM3N1IiAQEYObc0mIJDmZmpEQCAjh7ZmExBIczM1IiCQkUNbswkIpLmZGhEQyMihrdkEBNLcTI0ICGTk0NZsAgJpbqZGBAQycmhrNgGBNDdTIwICGTm0NZuAQJqbqREBgYwc2ppNQCDNzdSIgEBGDm3NJiCQ5mZqREAgI4e2ZhMQSHMzNSIgkJFDW7MJCKS5mRoREMjIoa3ZBATS3EyNCAhk5NDWbAICaW6mRgQEMnJoazYBgTQ3UyMCAhk5tDWbgECam6kRAYGMHNqaTUAgzc3UiIBARg5tzSYgkOZmakRAICOHtmYTEEhzMzUiIJCRQ1uzCQikuZkaERDIyKGt2QQE0txMjQgIZOTQ1mwCAmlupkYEBDJyaGs2AYE0N1MjAgIZObQ1m4BAmpupEYEHfwiO5E9bqSQAAAAASUVORK5CYII=";

			if (this.byId("proofCheckBox").getSelected())
				if (!this.byId("signBox").getSelected())
					if (document.getElementById("signature-pad").toDataURL() === planiImg) {
						document.getElementById("signature-pad").style.borderColor = "red";
						MessageToast.show("Please Sign!!");
						return;
					} else {
						document.getElementById("signature-pad").style.borderColor = "black";
					}
			if (this.byId("arrivalDest").getSelected() && this.byId("unload").getSelected() && this.byId("proofCheckBox").getSelected()) {
				oProductsPayload.FUFlag = this.jsonM.getData().FUFlag;
			}
			var eset = "/UpdateDetailsSet";
			oProductsPayload.ProductDetailsSet = arrayData;

			MessageToast.show("Sending Data");
			this.getView().setBusy(true);

			odatamodelupdate.create(eset, oProductsPayload, {
				success: function (odata, response) {

					if (JSON.parse(response.headers["sap-message"]).severity === "error") {
						MessageBox.error(JSON.parse(response.headers['sap-message']).message, {
							onClose: function (oAction) {
								this.goBack();
							}.bind(this)
						});
						this.getView().setBusy(false);
						return;
					}

					if (this.byId("proofCheckBox").getSelected())
						if (!this.byId("signBox").getSelected())
							this.signatureUpload();

					if (this.byId("signBox").getSelected()) {
						if (this.getView().byId("UploadCollection").getItems().length > 0) {
							this.getView().byId("UploadCollection").upload();
						} else {
							this.getView().setBusy(false);
							MessageToast.show(JSON.parse(response.headers['sap-message']).message);
							this.goBack();
						}
					}

					if (!this.byId("proofCheckBox").getSelected()) {
						MessageToast.show(JSON.parse(response.headers['sap-message']).message);
						this.getView().setBusy(false);
						this.goBack();
					}
				}.bind(this),
				error: function (erMsg) {
					this.getView().setBusy(false);
					MessageToast.show("Failed:Update001:" + erMsg);
					this.goBack();
				}.bind(this)
			});

		},

		signatureUpload: function () {
			var odatamodelupdate = this.getView().getModel();
			var sImg = document.getElementById("signature-pad").toDataURL('image/jpeg', 1).replace(/^data:.+;base64,/, '');
			odatamodelupdate.create("/AttachmentSet", sImg, {
				headers: {
					slug: this.jsonM.getData().frtOrdNum + "/" + "sign.jpeg" + "/X" + "/" + this.jsonM.getData().freightNumber +
						"/" + this.jsonM.getData().DeliveryNum + "/" + this.jsonM.getData().trucknum + "/" + this.jsonM.getData().TMFlag
				},
				success: function (oData, oResponse) {
					var message = JSON.parse(oResponse.headers["sap-message"]).message;
					this.clearButton();

					if (this.getView().byId("UploadCollection").getItems().length > 0) {
						this.getView().byId("UploadCollection").upload();
					} else {
						this.getView().setBusy(false);
						MessageToast.show(message);
						this.goBack();
					}
				}.bind(this),
				error: function () {
					this.getView().setBusy(false);
					MessageToast.show("Signature Upload Failed!!");
				}.bind(this)
			});
		},

		goBack: function () {
			this.oEventDialog = undefined;
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				oRouter.navTo("RouteView1");
			}
		},

		onPressReject: function () {

			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			MessageBox.confirm("Unsaved Data will be lost. Do you want to Continue" + "?", {
				onClose: function (oAction) {
					if (oAction === MessageBox.Action.OK) {
						this.oEventDialog = undefined;
						MessageToast.show("Going Back!! ", {
							duration: 500
						});
						if (sPreviousHash !== undefined) {
							window.history.go(-1);
						} else {
							oRouter.navTo("RouteView1");
						}

					} else {
						MessageToast.show("Canceled!!", {
							duration: 500
						});
					}
				}.bind(this)
			});
		},

		singInfo: function (oEvent) {
			if (this.byId("signBox").getSelected()) {
				this.clearButton();
				this.byId("signLayout").setVisible(false);
			} else {
				this.byId("signLayout").setVisible(true);
			}
		},

		proofOfDelivery: function (oEvent) {

			if (this.byId("proofCheckBox").getSelected()) {
				this.byId("proofLayout").setVisible(true);

				this.signPanel();

			} else {
				if (oEvent !== undefined) {
					MessageBox.confirm("Unsaved Data will be lost. Do you want to Continue" + "?", {
						onClose: function (oAction) {
							if (oAction === MessageBox.Action.OK) {
								this.byId("signBox").setSelected(false);
								this.singInfo();
								this.byId("proofLayout").setVisible(false);
								this.clearButton();
								this.byId("UploadCollection").removeAllItems();
							} else {
								this.byId("proofCheckBox").setSelected(true);
							}
						}.bind(this)
					});
				} else {
					this.byId("proofLayout").setVisible(false);
				}

			}
		},

		signPanel: function () {
			this.getView().byId("html").setContent("<canvas id='signature-pad' width='200' height='100' class='signature-pad'></canvas>");

			setTimeout(function () {
				this.canvas = document.getElementById("signature-pad");
				this.canvas.style.border = "1px solid black";
				this.context = this.canvas.getContext("2d");
				this.canvas.width = 200;
				this.canvas.height = 100;
				this.context.fillStyle = "#fff";
				this.context.strokeStyle = "#444";
				this.context.lineWidth = 1.5;
				this.context.lineCap = "round";
				this.context.fillRect(0, 0, this.canvas.width, this.canvas.height);
				this.disableSave = true;
				this.pixels = [];
				var cpixels = [];
				this.xyLast = {};
				this.xyAddLast = {};
				this.calculate = false;
				var functions = {
					remove_event_listeners: function () {
						this.canvas.removeEventListener('mousemove', functions.on_mousemove, true);
						this.canvas.removeEventListener('mouseup', functions.on_mouseup, true);
						document.body.removeEventListener('mouseup', functions.on_mouseup, true);
					}.bind(this),

					get_coords: function (e) {
						var x, y;

						if (e.changedTouches && e.changedTouches[0]) {
							var canvasArea = this.canvas.getBoundingClientRect();
							var offsety = canvasArea.top || 0;
							var offsetx = canvasArea.left || 0;
							x = e.changedTouches[0].pageX - offsetx;
							y = e.changedTouches[0].pageY - offsety;
						} else if (e.layerX || 0 == e.layerX) {
							x = e.layerX;
							y = e.layerY;
						} else if (e.offsetX || 0 == e.offsetX) {
							x = e.offsetX;
							y = e.offsetY;
						}

						return {
							x: x,
							y: y
						};
					}.bind(this),

					on_mousedown: function (e) {
						e.preventDefault();
						e.stopPropagation();

						this.canvas.addEventListener('mouseup', functions.on_mouseup, true);
						this.canvas.addEventListener('mousemove', functions.on_mousemove, true);
						this.canvas.addEventListener('touchend', functions.on_mouseup, true);
						this.canvas.addEventListener('touchmove', functions.on_mousemove, true);
						document.body.addEventListener('mouseup', functions.on_mouseup, true);
						document.body.addEventListener('touchend', functions.on_mouseup, true);
						var xy = functions.get_coords(e);
						this.context.beginPath();
						this.pixels.push('moveStart');
						this.context.moveTo(xy.x, xy.y);
						this.pixels.push(xy.x, xy.y);
						this.xyLast = xy;
					}.bind(this),

					on_mousemove: function (e, finish) {
						e.preventDefault();
						e.stopPropagation();

						var xy = functions.get_coords(e);
						var xyAdd = {
							x: (this.xyLast.x + xy.x) / 2,
							y: (this.xyLast.y + xy.y) / 2
						};

						if (this.calculate) {
							var xLast = (this.xyAddLast.x + this.xyLast.x + xyAdd.x) / 3;
							var yLast = (this.xyAddLast.y + this.xyLast.y + xyAdd.y) / 3;
							this.pixels.push(xLast, yLast);
						} else {
							this.calculate = true;
						}

						this.context.quadraticCurveTo(this.xyLast.x, this.xyLast.y, xyAdd.x, xyAdd.y);
						this.pixels.push(xyAdd.x, xyAdd.y);
						this.context.stroke();
						this.context.beginPath();
						this.context.moveTo(xyAdd.x, xyAdd.y);
						this.xyAddLast = xyAdd;
						this.xyLast = xy;

					}.bind(this),

					on_mouseup: function (e) {
						functions.remove_event_listeners();
						functions.disableSave = false;
						functions.calculate = false;
					}.bind(this)
				};
				this.canvas.addEventListener('touchstart', functions.on_mousedown, true);
				this.canvas.addEventListener('mousedown', functions.on_mousedown, true);
			}, 500);
		},

		clearButton: function (oEvent) {
			this.canvas = document.getElementById("signature-pad");
			this.context = this.canvas.getContext("2d");
			this.canvas.width = 200;
			this.canvas.height = 100;
			this.context.fillStyle = "#fff";
			this.context.strokeStyle = "#444";
			this.context.lineWidth = 1.5;
			this.context.lineCap = "round";
			this.context.fillRect(0, 0, this.canvas.width, this.canvas.height);
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.enoc.view.View2
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.enoc.view.View2
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.enoc.view.View2
		 */
		//	onExit: function() {
		//
		//	}

	});

});